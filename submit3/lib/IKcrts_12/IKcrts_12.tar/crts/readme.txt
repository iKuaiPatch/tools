iKuai: portal.ikuai8-wifi.com
OEM: portal.topspeedwifi.com
