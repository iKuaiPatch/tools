chmod +x /tmp/ikpkg/pmd/pmd
version=111
v=$(/tmp/ikpkg/pmd/pmd -v)
if [ "$v" != "$version" ]; then
    exit 1
fi
## 监控安装总体思路: 固化过pmd的路由，后面不管怎么升级云端的新版本，本地都不会安装服务端pmd安装包里的监控
## /tmp/pmd_crond_monitor 作为安装判断的依据flag, 该标识文件在pmd卸载时不被删除，需要作为路由全局状态
## 文件存在表示本地没有固化过pmd, 监控需要由安装包来做
## 约定条件: 固化过pmd的路由版本，pmd的监控工作由系统本身来做
need_install_monitor=no
crond_monitor_flag=/tmp/pmd_crond_monitor
if [ ! -f /usr/sbin/pmd ] ; then
    need_install_monitor=yes
else
    if [ -L /usr/sbin/pmd  ] && [ -f ${crond_monitor_flag}  ]; then
        ### pmd 为软连接，且有标识存在,
        need_install_monitor=yes
    fi
        ### 其他情况表示本地曾经或者现在是固化pmd的路由版本
fi
if [ -f /usr/sbin/pmd ]; then
    rm /usr/sbin/pmd
fi
if [ -f /usr/bin/pmd ]; then
    rm /usr/bin/pmd
fi
ln -s /tmp/ikpkg/pmd/pmd /usr/sbin/pmd
if pidof pmd; then
    kill -s SIGUSR1 $(pidof pmd)
else
    pmd
fi
router_release="3.0"
crontab_prefix="/etc/crontabs"
if [ ! -f /etc/release ]; then
    crontab_prefix="/tmp/iktmp/crontabs"
    router_release="2.0"
    need_install_monitor=yes
else
    rootfs_avail=$(df / -k 2>/dev/null | awk 'NR==2{print}' | awk '{print $4}')
    if [ $? -eq 0 ]; then
        ## min rootfs space limit: 2M
        ## Don't overwrite crontab file if disk space size was little than this value
        ## /etc/crontabs/root is possible writen failed while rootfs is under low available space size status
        ## and that will have a Bad impact on other Functions On Router.
        if [ ${rootfs_avail} -lt 2048 ]; then
            need_install_monitor=no
        fi
    fi
fi
## mainly test for 2.7.x, because the dir may be created failed because of submit error
if [ ! -d ${crontab_prefix} ]; then
  need_install_monitor=no
fi
if [ -f /tmp/ikpkg/pmd/monitor.sh ] && [ ${need_install_monitor} == yes ]; then
    if [ -f ${crontab_prefix}/cron.d/pmd ]; then
        rm -f ${crontab_prefix}/cron.d/pmd
    fi
    chmod +x /tmp/ikpkg/pmd/monitor.sh
    echo "* * * * * /tmp/ikpkg/pmd/monitor.sh" > ${crontab_prefix}/cron.d/pmd
    random_filename=$(date +%s%N).${RANDOM}
    cat ${crontab_prefix}/cron.d/* > ${crontab_prefix}/${random_filename}
    mv ${crontab_prefix}/${random_filename} ${crontab_prefix}/root
    if [ ${router_release} == "3.0" ]; then
        crontab ${crontab_prefix}/root
    else
        crontab -c ${crontab_prefix} ${crontab_prefix}/root
    fi
    touch ${crond_monitor_flag}
fi
