#!/bin/bash

if ! pidof pmd 2>/dev/null; then
	pmd
fi
