#!/bin/bash

CRE_BIN=cre
TKGEN_BIN=tkgen
IK_CRE_PATH=/usr/sbin/${CRE_BIN}
IK_TKGEN_PATH=/usr/sbin/${TKGEN_BIN}
OLD_IK_CRE_PATH_BAK=${IK_CRE_PATH}.bak
ROUTER_VERSION=300050005

OLD_IK_ROUTE_COLLECT_BIN=ik_route_collect
OLD_IK_ROUTE_COLLECT_PATH=/usr/bin/${OLD_IK_ROUTE_COLLECT_BIN}
OLD_IK_ROUTE_COLLECT_BAK=/usr/bin/${OLD_IK_ROUTE_COLLECT_BIN}.bak
OLD_IK_ROUTE_COLLECT_OLD=/usr/bin/${OLD_IK_ROUTE_COLLECT_BIN}.old

ERROR_LOG_PATH=${INSTALL_DIR}/error.log

function _log_time()
{
	local error_info=`date +'%G/%m/%d %H:%M:%S'`
	error_info=${error_info}" ["$1"] "$2
	echo "${error_info}"
}
function _write_log()
{
	_log_time "$1" "$2" >> ${ERROR_LOG_PATH}
	return 0
}
function write_info_log()
{
	_write_log "info" "$1"
}
function write_error_log()
{
	_write_log "error" "$1"
}
function write_warn_log()
{
	_write_log "warn" "$1"
}

function __check_cre(){
	if [ -f $OLD_IK_ROUTE_COLLECT_BAK ]; then
		local pid=`cat /var/run/collect_report_engine.pid 2>/dev/null`
		if [ -f /proc/${pid}/exe ]; then
			return 0
		else
			return 1
		fi
	else
		return 0
	fi
}


function __try_stop()
{
	local  bin_name=$1

	## try to stop old bin
	killall  -s SIGINT  ${bin_name} 2>/dev/null
	local n=10
	while [ "$((n--))" -gt 0 ] && __check_cre ; do
		sleep 1
	done
	if __check_cre ;then
		write_warn_log "kill ${bin_name} forcefully"
		killall -s SIGKILL ${bin_name}
		sleep 1
	fi
}

function __rollback_old_collect()
{
	if [ -f ${OLD_IK_CRE_PATH_BAK} ]; then
                mv ${OLD_IK_CRE_PATH_BAK} ${IK_CRE_PATH}
                write_warn_log "rollback old cre"
        fi

	[ -f ${OLD_IK_ROUTE_COLLECT_BAK} ] || return

	mv -f ${OLD_IK_ROUTE_COLLECT_BAK}  ${OLD_IK_ROUTE_COLLECT_PATH}
	write_warn_log "rollback old collect"
}

function __install_and_run()
{
	echo "install and run ${IK_ROUTE_COLLECT_BIN}"

        ## back up old cre
        if [ -f ${IK_CRE_PATH} -a ! -h ${IK_CRE_PATH} ]; then
                mv ${IK_CRE_PATH} ${OLD_IK_CRE_PATH_BAK}
	else
		ln -s  ${INSTALL_DIR}/${CRE_BIN} ${IK_TKGEN_PATH}
        fi

	## creat soft link
	ln -s  ${INSTALL_DIR}/${CRE_BIN} ${IK_CRE_PATH}

	## show version for test the bin
	if ! ${CRE_BIN} -V ; then
		write_error_log "run ${CRE_BIN} -V failed"
		__rollback_old_collect
		exit 1
	fi
	echo "s0=$@"
	## start new bin
	[ "$1" = "install" ] && shift

	if [ -f ${OLD_IK_ROUTE_COLLECT_BAK} ] && which ${OLD_IK_ROUTE_COLLECT_BIN} ; then
		## Must use old name, if not  monitor can find new collect bin
		${OLD_IK_ROUTE_COLLECT_BIN} "$@"
	else
		${CRE_BIN} "$@"
	fi
}

function __router_version_if_new()
{
        [ -f  /etc/release  ] || return 1

        local $(grep -w VERSION_NUM /etc/release)

        if [ -z "${VERSION_NUM}"  ] ; then
                write_error_log "no VERSION_NUM in /etc/release"
                return 1
        fi

        [ "${VERSION_NUM}" -ge  "${ROUTER_VERSION}" ] && return 0 || return 1

}


function __try_handle_old_collect()
{
	if [ ! -f ${OLD_IK_ROUTE_COLLECT_PATH} ] ; then
		write_error_log "this is new version"
		return
	fi

        if __router_version_if_new ; then
                echo "This is new system with cre"
                mv ${OLD_IK_ROUTE_COLLECT_PATH} ${OLD_IK_ROUTE_COLLECT_OLD}
                return
        fi

	if [ -L ${OLD_IK_ROUTE_COLLECT_PATH}  ] ; then
		echo "Aleady handler old system"
		return
	fi

	## then handle old system
	if ! mv -f  ${OLD_IK_ROUTE_COLLECT_PATH} ${OLD_IK_ROUTE_COLLECT_BAK} ; then
		write_error_log "mv ${IK_ROUTE_COLLECT_BIN} failed"
		return
	fi

	__try_stop  ${OLD_IK_ROUTE_COLLECT_BIN}

	ln -s ${INSTALL_DIR}/${CRE_BIN} ${OLD_IK_ROUTE_COLLECT_PATH}

}

function __check_new_collect()
{
	local n=5
	while [ "$((n--))" -gt 0 ] ; do
		sleep 1
		if __check_cre ; then
			echo "new collect runs well"
			return
		fi
	done

	__rollback_old_collect
	return 1
}

function main()
{
	rm -f ${ERROR_LOG_PATH}
	__try_handle_old_collect
	__install_and_run  "$@"
	__check_new_collect
}


main "$@"
