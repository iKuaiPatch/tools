#!/bin/bash

CRE_BIN=cre
TKGEN_BIN=tkgen
IK_CRE_PATH=/usr/sbin/${CRE_BIN}
IK_TKGEN_PATH=/usr/sbin/${TKGEN_BIN}
OLD_IK_CRE_PATH_BAK=${IK_CRE_PATH}.bak

OLD_IK_ROUTE_COLLECT_BIN=ik_route_collect
OLD_IK_ROUTE_COLLECT_PATH=/usr/bin/${OLD_IK_ROUTE_COLLECT_BIN}
OLD_IK_ROUTE_COLLECT_BAK=/usr/bin/${OLD_IK_ROUTE_COLLECT_BIN}.bak


function __check_cre(){
        if [ -f $OLD_IK_ROUTE_COLLECT_BAK ];then
                local pid=`cat /var/run/collect_report_engine.pid 2>/dev/null`
                if [ -f /proc/${pid}/exe ]; then
                        return 0
                else
                        return 1
                fi
        else
                return 0
        fi
}

function __try_stop()
{
	if ! which ${CRE_BIN} 2>/dev/null >/dev/null ; then
		echo "no ${CRE_BIN}"
		return 0
	fi
	echo "stop ${CRE_BIN}"
	if [ ! -f ${OLD_IK_CRE_PATH_BAK} -a -h ${IK_CRE_PATH} ]; then
		rm -f ${IK_TKGEN_PATH}
	fi
	if [ -f ${IK_CRE_PATH} -a -h ${IK_CRE_PATH} ]; then
		rm -f ${IK_CRE_PATH}
	fi
	## try to stop old bin
	killall -s SIGINT ${CRE_BIN} 2>/dev/null
	local n=10
	while [ "$((n--))" -gt 0 ] && [ __check_cre == 1 ] ; do
		sleep 1
	done
	if __check_cre ;then
		echo "kill ${CRE_BIN} forcefully"
		killall -s SIGKILL ${CRE_BIN}
		sleep 1
	fi
}


function __rollback_old_collect()
{
	if [ -f ${OLD_IK_CRE_PATH_BAK} ]; then
                mv ${OLD_IK_CRE_PATH_BAK} ${IK_CRE_PATH}
        fi

	[ -f ${OLD_IK_ROUTE_COLLECT_BAK} ] || return

	mv -f ${OLD_IK_ROUTE_COLLECT_BAK}  ${OLD_IK_ROUTE_COLLECT_PATH}
}

function main()
{
	__try_stop
	echo "finish uninstall ${CRE_BIN}"
	__rollback_old_collect
}


main
