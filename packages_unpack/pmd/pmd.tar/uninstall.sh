router_release="3.0"
crontab_prefix="/etc/crontabs"
if [ ! -f /etc/release ]; then
    crontab_prefix="/tmp/iktmp/crontabs"
    router_release="2.0"
fi
if [ -f ${crontab_prefix}/cron.d/pmd ] && [ -f /tmp/pmd_crond_monitor ];  then
    >${crontab_prefix}/cron.d/pmd
    random_filename=$(date +%s%N).${RANDOM}
    cat ${crontab_prefix}/cron.d/* > ${crontab_prefix}/${random_filename}
    mv ${crontab_prefix}/${random_filename} ${crontab_prefix}/root
    if [ ${router_release} == "3.0" ]; then
        crontab ${crontab_prefix}/root
    else
        crontab -c ${crontab_prefix} ${crontab_prefix}/root
    fi
    rm -f ${crontab_prefix}/cron.d/pmd
fi
rm -f /usr/sbin/pmd
rm -f /usr/bin/pmd
