local Cookie       = ikngx.cookie.new()
local SessKey      = Cookie.req_cookies["sess_key"]

local LANG      = GLOBAL.LANG
local TIMEZONE  = GLOBAL.TIMEZONE
local IKRELEASE = GLOBAL.IKRELEASE

ngx.header["Server"]        = "Nginx"
ngx.header["Expires"]       = 0
ngx.header["Pragma"]        = "no-cache"
ngx.header["Cache-Control"] = "no-cache"
ngx.header["X-LANG"]        = LANG
ngx.header["X-Timezone"]    = TIMEZONE
ngx.header["X-Timestamp"]   = ngx.time()
ngx.header["X-Arch"]        = IKRELEASE.ARCH
ngx.header["X-Sysbit"]      = IKRELEASE.SYSBIT
ngx.header["X-Enterprise"]  = IKRELEASE.ENTERPRISE and 1 or 0
ngx.header["X-Support-i18n"]  = IKRELEASE.SUPPORT_I18N and 1 or 0
ngx.header["X-Support-wifi"]  = IKRELEASE.MIPS_WIFI_SUPPORT_2G and 1 or 0

local Session = ngx.shared.sess_key
local ScreenSessTimeout = 120

local ResOK           = 10000  --验证账号密码成功
local ResAuthFail     = 10001  --验证账号密码失败
local ResAccDisable   = 10002  --账号是停用的
local ResInvalidIP    = 10003  --无效的IP
local ResPermNR       = 10004  --没有读权限
local ResPermNX       = 10005  --没有执行权限
local ResCallBodyErr  = 10006  --Body内容太大
local ResCallJsonErr  = 10007  --Json格式错误
local ResCallParamErr = 10008  --参数内容错误
local ResCallInternal = 10009  --服务器内部错误
local ResUpSvrErr     = 10010  --上传文件,服务器错误
local ResUpFormatErr  = 10011  --上传文件,FORM表单格式错误
local ResDownloadErr  = 10012  --下载文件,请求参数错误
local ResIkrestErr    = 10013  --ik_rest HTTP 状态错误 
local ResNoAuth       = 10014  --未认证/认证SESS过期

local VerifyExclUri   = {}
VerifyExclUri["^/static/screen"]        = true
VerifyExclUri["^/favicon.ico"]    = true

local ngx_var_uri = ngx.var.uri
local req_args     = ngx.req.get_uri_args() or {}
local now_times = ngx.time()

local function KeyVerify(key, timestamp, yuncode)
	--key 10分钟有效期前端url中timestamp无法改变；导致10分钟后会过期，先注销此处校验
	--if math.abs(now_times-timestamp) > 600 then
	--	ngx.exit(403)
	--end		

	ngx.log(ngx.INFO, "########### yuncode=", yuncode or "--")
	local len = string.len(yuncode)
	local screen_str = string.format("%s%s%s", string.sub(yuncode, 1, len/2), req_args.timestamp, string.sub(yuncode, len/2+1, len))
	local screen_token = ngx.md5(screen_str)

	if screen_token ~= key then
		ngx.exit(403)
	end
end

--根据session key 获得用户名
local function getUername(sess_key)
	if not sess_key then
		return nil
	end

	local user_and_times = Session:get(sess_key)
	if not user_and_times then
		return nil
	end

	local username, old_times = string.match(user_and_times, "([^&]+)&([0-9]+)")
	return username, tonumber(old_times)
end


local function CheckReqMethod(m, exit_num)
	exit_num = exit_num or 401
	if ngx.var.request_method ~= m then
		ngx.exit(exit_num)
	end
end

local function VerifyReqExcl()
	for uri, _ in pairs(VerifyExclUri) do
		if string.find(ngx.var.uri, uri) then
			return true
		end
	end
	return false
end

local function VerifyScreenSesskey(cookie)
	--验证Session Key 是否存在,如果是过期的 查询结果是 nil
	local sess_key = cookie.req_cookies["sess_key"]
	local username, old_times = getUername(sess_key)
	if not username then
		return nil
	end

	if old_times > now_times or now_times - old_times > ScreenSessTimeout/2 then
		local res, err = Session:set(sess_key, username.."&"..now_times, ScreenSessTimeout)
		if not res then
			ngx.log(ngx.ERR,"reset sess timeout fail for "..sess_key..", errmsg = " ..err)
		end
	end
	return username
end

local function ActionScreen(cookie, username)
	CheckReqMethod("POST")

	if not req_args.key and not req_args.timestamp and not req_args.code then
		ikngx.senderror(ResCallParamErr, "key or timestamp or code must set")
	end

	ngx.req.read_body()
	if not ngx.var.request_body then
		ikngx.senderror(ResCallBodyErr, "Post body null")
	end
	local screen_users = req_args.key .. req_args.timestamp
	local username = VerifyScreenSesskey(cookie)
	if not username then	
		
		KeyVerify(req_args.key, req_args.timestamp, req_args.code)

		local key = ngx.md5(now_times .. ngx.var.request_body .. ngx.var.remote_port .. ngx.var.remote_addr )
		Session:set(key, screen_users.."&"..now_times, ScreenSessTimeout)
		cookie:set({key="sess_key", value=key, path="/"})
	else
		if screen_users ~= username then
			cookie:set({key="sess_key", value="", path="/"})
			ikngx.senderror(ResCallParamErr, "authentication failed")
		end
	end
	
	local res, call_json_tab = pcall(cjson.decode, ngx.var.request_body)
	if not res then
		ikngx.senderror(ResCallJsonErr, "decode json fail")
	end

	local func_name = call_json_tab["func_name"]
	if not func_name or func_name == "" then
		ikngx.senderror(ResCallParamErr, 'func_name is null')
	end

	local action = call_json_tab["action"]
	if not action or action == "" then
		ikngx.senderror(ResCallParamErr, 'action is null')
	end

	if func_name ~= "screen" and action ~= "show" then
		ikngx.senderror(ResCallParamErr, 'func_name or action error')
	end

	local ok, buf = ikngx.rest(call_json_tab, env)
	ngx.header["Content-Type"]  = "application/json;charset=UTF-8"

	if ok then	
		ngx.header["Content-Length"] = #buf
		ngx.print(buf)
	else
		ikngx.senderror2(ResIkrestErr, buf)
	end

	ngx.exit(0)
end

if string.find(ngx_var_uri, "^/static/screen/index.html") then
	KeyVerify(req_args.key, req_args.timestamp, req_args.code)
end

if not VerifyReqExcl() then
	ActionScreen(Cookie,SessKey)
end
