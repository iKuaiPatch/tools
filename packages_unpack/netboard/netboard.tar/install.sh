#!/bin/bash 
install()
{
	mkdir -p /usr/ikuai/www/static/screen
	
	ln -sf $INSTALL_DIR/echarts.js /usr/ikuai/www/static/screen/echarts.js
	ln -sf $INSTALL_DIR/index.html /usr/ikuai/www/static/screen/index.html
	ln -sf $INSTALL_DIR/test.js /usr/ikuai/www/static/screen/test.js

	mkdir -p /usr/openresty/conf/plugins
	ln -sf $INSTALL_DIR/screen.conf /usr/openresty/conf/plugins/screen.conf
	ln -sf $INSTALL_DIR/screen.lua /usr/openresty/lua/webman/screen.lua
	ln -sf $INSTALL_DIR/local.crt /usr/openresty/ssl/local.crt
	ln -sf $INSTALL_DIR/local.key /usr/openresty/ssl/local.key


	ln -sf $INSTALL_DIR/screen.sh /usr/ikuai/function/screen

	ipset add DROP_T_PORTS_WAN_IN 770

	openresty -s reload &
}

uninstall()
{
	rm -f /usr/ikuai/www/static/screen/echarts.js
	rm -f /usr/ikuai/www/static/screen/index.html
	rm -f /usr/ikuai/www/static/screen/test.js
	rm -f /usr/openresty/ssl/local.key
	rm -f /usr/openresty/ssl/local.crt
	rm -f /usr/openresty/conf/plugins/screen.conf
	rm -f /usr/openresty/lua/webman/screen.lua

	ipset del DROP_T_PORTS_WAN_IN 770

	openresty -s reload &	
}

procname=$(basename $BASH_SOURCE)
if [ "$procname" = "install.sh" ];then
        install
elif [ "$procname" = "uninstall.sh" ];then
        uninstall
fi
