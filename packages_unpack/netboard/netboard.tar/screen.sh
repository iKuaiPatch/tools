#!/bin/bash /etc/ikcommon
Include interface.sh, ifether.sh

show()
{
	Show __json_result__
}

__show_sysstat()
{
	local sysstat=$($IK_DIR_SCRIPT/sysstat.sh show TYPE=all)
	json_append __json_result__ sysstat:json
}

__show_l7proto_stat()
{
	local l7proro_stat
	while read config; do
		[ "$config" ] || continue
		local proto_info=($config)
		local name="${proto_info[0]}"
		local upload="${proto_info[2]}"
		local download="${proto_info[3]}"
		local total_upload="${proto_info[4]}"
		local total_download="${proto_info[5]}"
		local tmp_one=$(json_output name:str upload:str download:str total_upload:str total_download:str)
		local l7proro_stat+="${l7proro_stat:+,}$tmp_one"
	done < /proc/ikuai/stats/ik_proto_stats

	l7proro_stat="[$l7proro_stat]"
	json_append __json_result__ l7proro_stat:json
}

__show_app_historical()
{
	local app_historical=$($IK_DIR_SCRIPT/monitor_system.sh show TYPE=app_historical)
	json_append __json_result__ app_historical:json
}

__show_ac_status()
{
	local ap_count=$(ls /tmp/iktmp/cache/config/AC/[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]* |wc -l)
	local ap_online=$(wum -c wtps|wc -l)

	ac_status=$(json_output ap_count:int ap_online:int)
	json_append __json_result__ ac_status:json
}

__show_terminal()
{
	local mobile=0
	local pc=0
	while read config; do
		[ "$config" ] || continue
		local hosts=($config)
		if [ "${hosts[12]}" = "Android" -o "${hosts[12]}" = "iOS" ]; then
			mobile=$((mobile+1))
		else
			pc=$((pc+1))
		fi
	done < /proc/ikuai/stats/host_stats

	json_append __json_result__ mobile:int pc:int
}

__show_near_dev_status()
{
	local dev_control_total=0 dev_control_online=0
	for tmpfile in $(ls /tmp/iktmp/cache/dev_control/status.* 2>/dev/null); do
		dev_control_total=$((dev_control_total+1))
		local res=$(cat $tmpfile 2>/dev/null)
		[ "$res" = "1" ] && dev_control_online=$((dev_control_online+1))
	done

	local cloud_switch_status=$(json_output dev_control_total:int dev_control_online:int)

	json_append __json_result__ cloud_switch_status:json
}

__show_cloud_switch_status()
{
	local switch_onlie=0 switch_total=0
	local cloud_filelist=$(find /tmp/iktmp/cache/cloud_switch/ -name "[0-9]*" -type d)
	for fileone in ${cloud_filelist}; do
		switch_total=$((switch_total+1))
		local res=$(cat $fileone/status 2>/dev/null)
		 [ "$res" = "1" -o "$res" = "2" ] && switch_online=$((switch_online+1))
	done

	local near_dev_status=$(json_output switch_onlie:int switch_total:int)

	json_append __json_result__ near_dev_status:json 
}
