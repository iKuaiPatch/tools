#!/bin/bash 
DOCKER_ENGINE_PATH=$INSTALL_DIR
install()
{
	rm -rf /usr/ikuai/www/plugins/docker
	ln -sf $DOCKER_ENGINE_PATH/html /usr/ikuai/www/plugins/docker

	ln -sf $DOCKER_ENGINE_PATH/script/ikdocker.lua         /usr/sbin/ikdocker
	ln -sf $DOCKER_ENGINE_PATH/script/docker_container.sh  /usr/ikuai/function/docker_container
	ln -sf $DOCKER_ENGINE_PATH/script/docker_image.sh      /usr/ikuai/function/docker_image
	ln -sf $DOCKER_ENGINE_PATH/script/docker_network.sh    /usr/ikuai/function/docker_network
	ln -sf $DOCKER_ENGINE_PATH/script/docker_server.sh     /usr/ikuai/function/docker_server

	$DOCKER_ENGINE_PATH/script/docker_server.sh boot >/dev/null 2>&1 &
}

__uninstall()
{
	/usr/ikuai/function/docker_server __stop_dockerd
	rm -rf  /usr/sbin/ikdocker \
		/usr/ikuai/function/docker_container \
		/usr/ikuai/function/docker_image \
		/usr/ikuai/function/docker_network \
		/usr/ikuai/function/docker_server
	rm -rf /usr/ikuai/www/plugins/docker
}

uninstall()
{
	__uninstall >/dev/null 2>&1
}

procname=$(basename $BASH_SOURCE)
if [ "$procname" = "install.sh" ];then
        install
elif [ "$procname" = "uninstall.sh" ];then
        uninstall
fi
