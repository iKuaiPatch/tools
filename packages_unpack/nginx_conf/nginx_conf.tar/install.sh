#!/bin/bash 
install()
{
	mkdir -p /usr/openresty/conf/plugins
	local res=$(awk -v conf="conf/plugins/*.conf;" '{if($2==conf){print $2}}' /usr/openresty/nginx.conf)
	if [ -z "$res" ]; then
		awk -vinsert="\n\tinclude conf/plugins/*.conf;" '{print; if($1=="init_by_lua_file")print insert}' /usr/openresty/nginx.conf > /tmp/ngx.$$	
		mv /tmp/ngx.$$ /usr/openresty/nginx.conf
		openresty -s reload &
	fi
}

uninstall()
{
	return
}

procname=$(basename $BASH_SOURCE)
if [ "$procname" = "install.sh" ];then
        install
elif [ "$procname" = "uninstall.sh" ];then
        uninstall
fi
